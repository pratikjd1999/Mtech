studentData = {}
try:
    while (1):
        print(" 1.Insert Student\n 2.Delete Student\n 3.Update data\n 4.Display\n 5.Exit\n")
        inputChoice = int(input("Enter Your Choice: "))
        if inputChoice == 1:
            Roll_No = int(input("Enter student Roll no: "))
            Name = input("Enter student name: ")
            studentData[Roll_No] = Name
            continue
        elif inputChoice == 2:
            index = int(input("Enter roll_no to delete record: "))
            result = studentData.pop(index)
            print("removed student name is : " + result)
            continue
        elif inputChoice == 3:
             num = int(input("Enter Roll_no to change record: "))
             name = input("Enter New name: ")
             studentData.update({num : name})
             continue
        elif inputChoice == 4:
            print(studentData)
            continue
        elif inputChoice == 5:
            print("Thank You")
            break
except:
    print ("something went wrong")