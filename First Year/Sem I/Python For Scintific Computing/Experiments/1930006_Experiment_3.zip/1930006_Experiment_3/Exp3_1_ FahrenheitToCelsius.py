celsius = 37.5

# calculate fahrenheit
fahrenheit = (celsius * 1.8) + 32
print()
print('%0.1f degree Celsius is equal to %0.1f degree Fahrenheit' %(celsius,fahrenheit))