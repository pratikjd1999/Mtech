# 9.	Find smallest number from given array.
class Experiment1_9:
    def findSmallestElementInArray(num_array):
       returnElement=num_array[0];
       for item in num_array:
           if item < returnElement:
                returnElement=item
       
       return returnElement

    try:
        num_array = list()
        limitOfArray = input("Enter how many elements do you want:")
        print('Enter numbers in array: ')
        for index in range(limitOfArray):
            number = input('num{0} :'.format(index+1))
            num_array.append(number)

        smallestElement = findSmallestElementInArray(num_array)
        print("smallest number in given array is "+str(smallestElement))
    except:
        print("please enter variables in integer")
