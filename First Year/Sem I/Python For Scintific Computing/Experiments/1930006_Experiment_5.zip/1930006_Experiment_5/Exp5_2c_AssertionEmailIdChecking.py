# c.Ask user to enter email ID and assert that entered ID contains @ symbol.
emailId = input("Please Enter EmailId : ")
assert("@" in emailId), "Please Enter EmailId with @"
print("You entered email with @")
