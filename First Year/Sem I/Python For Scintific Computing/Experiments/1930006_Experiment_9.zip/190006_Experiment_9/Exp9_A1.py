import numpy as np
x = np.random.normal(size=5)
print(x)