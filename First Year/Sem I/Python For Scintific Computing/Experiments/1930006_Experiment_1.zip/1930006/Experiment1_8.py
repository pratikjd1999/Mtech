#8.	Program to generate a random number between 0 and 9
import random
class Experiment1_8:
    print(random.randint(0, 9))
