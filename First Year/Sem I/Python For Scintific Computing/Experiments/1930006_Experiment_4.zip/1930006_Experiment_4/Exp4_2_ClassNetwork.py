class Person:
    def __init__(self, name, code):
        self.name = name
        self.code = code

    def get_per(self, name, code):
        print("inside get per")
        self.name = name
        self.code = code

    def put_per(self):
        print("Code is =>", self.code)
        print("Name is = >", self.name)

class Account (Person):
    def __init__(self, pay):
        self.pay = pay

    def get_pay(self, pay):
        print("inside get pay")
        self.pay = pay

    def put_pay(self):
        print("Pay amount =>", self.pay)

class Admin(Person):
    def __init__(self, exp):
        self.exp = exp

    def get_exp(self, exp):
        print("inside get exp")
        self.exp = exp

    def put_exp(self):
        print("Experience is =>", self.exp)

class Master(Account, Admin):
    def __init__(self):
        print ("master init")

    def display(self, a = 1):
        print ("inside display")
        Person.put_per(self)
        Admin.put_exp(self)
        Account.put_pay(self)


class MainClass:
    master = Master()
    master.get_per("john", 111)
    master.get_pay(5000)
    master.get_exp(5)
    master.display(master)