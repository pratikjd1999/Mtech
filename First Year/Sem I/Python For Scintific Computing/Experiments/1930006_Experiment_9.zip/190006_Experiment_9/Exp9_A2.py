import numpy as np
x = np.random.random((3, 3, 3))
print(x)