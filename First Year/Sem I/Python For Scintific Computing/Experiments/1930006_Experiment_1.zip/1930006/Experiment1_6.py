# 6.	Solve the quadratic equation ax**2 + bx + c = 0
import cmath
class Experiment1_6:

    def solveEquation(a,b,c):
         delta = (b**2) - (4*a*c)
         solution1 = (-b-cmath.sqrt(delta))/(2*a)
         solution2 = (-b+cmath.sqrt(delta))/(2*a)
         print('The solutions are {0} and {1}'.format(solution1,solution2))


    print('Solve the quadratic equation: ax**2 + bx + c = 0')
    try:
        a = float(input('Please enter a : '))
        b = float(input('Please enter b : '))
        c = float(input('Please enter c : '))
        solveEquation(a,b,c)
        
    except:
        print("please enter numbers in integer")