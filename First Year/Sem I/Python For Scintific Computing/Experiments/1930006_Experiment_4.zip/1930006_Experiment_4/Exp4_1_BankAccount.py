class Account:
    def __init__(self):
        pass
    def input(self,a):
        self.cname = input("Enter cname:")
        self.accNo = input("Enter Account number:")
        self.type = input("Enter type:")
        self.balance = int(input("Enter balance:"))

    def display(self,a):
        print("Customer name =>",self.cname)
        print("Account no =>",self.accNo)
        print("Type =>",self.type)
        print("Customer name =>",self.cname)
        print("Balance =>",self.balance)

    def deposite(self,a):
        amount = int(input("Enter Amount to deposite:"))
        self.balance = self.balance + amount


class SavingAccount(Account):
    def __init__(self):
        pass
    def comp_int(self):
        rate1 = 10
        time1 = input("Enter time")
        interest = self.balance * (1 + rate1 / 100) - self.balance

    def update_balance(self):
        self.balance = balance + 10 #Compound iterest

    def withdrawal(self, a):
        amount = int(input("Enter Amount to withdraw:"))
        if(self.balance > amount):
            self.balance = self.balance - amount
        else:
            print("Insufficient funds")


class CurrentAccount(Account):
    def __init__(self):
        pass
    def min_bal(self):
        self.ret1 = 1
        if(self.balance <= 500):
            penalty = 50
            self.balance = self.balance -penalty
            self.ret1 = 0
        else:
            print("No penalty applied")

    def withdrawal(self,a):
        amount = int(input("Enter Amount to withdraw:"))

        if(self.balance > amount):
            self.balance = self.balance - amount
        else:
            print("Insufficient funds,  cannot be withdrawn")

class MainClass:
    def createBankAccount():
        c1 = CurrentAccount()
        s1 = SavingAccount()

        c1.input(c1)
        c1.display(c1)

        c1.deposite(c1)
        c1.display(c1)

        c1.withdrawal(c1)
        c1.display(c1)

        s1.input(s1)
        s1.display(s1)

        s1.deposite(s1)
        s1.display(s1)

        s1.withdrawal(s1)
        s1.display(s1)

    createBankAccount()