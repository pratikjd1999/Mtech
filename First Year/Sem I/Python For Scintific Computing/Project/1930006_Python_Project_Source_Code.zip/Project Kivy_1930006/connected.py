from kivy.app import App
import kivy
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
kivy.require('1.7.1')
from kivy.uix.label import Label
from kivy.uix.popup import Popup

from plyer import tts

from kivy.uix.screenmanager import Screen, SlideTransition
import pyttsx3


class MyFileChooser(FileChooserListView):
    filename = "pratin"
    def on_submit(*args):
        MyFileChooser.filename = args[1]



# class LoadDialog(FloatLayout):
    # load = ObjectProperty(None)
    # cancel = ObjectProperty(None)
    #
    # def show_load_list(self):
    #     content = LoadDialog(load=self.load_list, cancel=self.dismiss_popup)
    #     self._popup = Popup(title="Load a file list", content=content, size_hint=(1, 1))
    #     self._popup.open()
    #
    # def load_list(self, path, filename):
    #     pass
    #
    # def dismiss_popup(self):
    #     self._popup.dismiss()
class WarningPopup(Popup):
    def __init__(self, parent_inst, *args,  **kwargs):
        super(WarningPopup, self).__init__(*args, **kwargs)
        self.parent_inst = parent_inst


class Connected(Screen):
    file_selected = []

    def disconnect(self):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = 'login'
        self.manager.get_screen('login').resetForm()
    def clear(self):
        self.saywhat_text.text = ""
        self.saywhat_text.focus = True

    def file_select(self):
        self.orientation = "vertical"
        self.fichoo  = MyFileChooser(filters=[lambda folder, filename: not filename.endswith('.sys')])
        self.btn_select = Button(text="Select", size_hint_y=0.1)
        self.btn_select.bind(on_press=self.select)

        self.add_widget(self.fichoo)
        self.add_widget(self.btn_select)


    def select(self, a):
        Connected.file_selected = self.fichoo.filename
        self.remove_widget(self.fichoo)
        self.remove_widget(self.btn_select)
        try:
            fname = Connected.file_selected[0]

            file = open(fname, 'r')
            lines = file.readlines()

            self.saywhat_text.text = ""

            for item in lines:
                self.saywhat_text.text += item

            self.saywhat_text.focus = True


        except IOError as e:
            print("I/O error({0}): {1}".format(e.errno, e.strerror))
        except:
            print("Something went wrong while reading from file")
        print("delete")

    def say_something(self, text):
        try:
            # tts.speak(text) #androd library

            engine = pyttsx3.init()

            # """VOICE"""
            voices = engine.getProperty('voices')  # getting details of current voice
            # engine.setProperty('voice', voices[0].id)  #changing index, changes voices. o for male
            engine.setProperty('voice', voices[1].id)  # changing index, changes voices. 1 for female

            engine.say(text)
            engine.runAndWait()
            # engine.stop()
        except:
            popup = Popup(title='Warning',
                          content=Label(text='Something Went Wrong!!!'),
                          size_hint=(None, None),
                          size=(300, 300))
            popup.open()

    def build(self):
        pass

    def on_pause(self):
        return True

    def on_resume(self):
        pass

if __name__ == '__main__':
    Connected().run()
