def removeDulicateTuples(list_touple):
    output = set([i for i in list_touple])
    print ("\nTuples after removing duplications ")
    print (list(output))



list_touple = [('a', 'b'), ('s', 't'), ('a', 'b'), ('c', 'd'), ('e', 'f'), ('s', 't')]
print ("\nTuples before removing duplications ")
print (list_touple)
removeDulicateTuples(list_touple)
