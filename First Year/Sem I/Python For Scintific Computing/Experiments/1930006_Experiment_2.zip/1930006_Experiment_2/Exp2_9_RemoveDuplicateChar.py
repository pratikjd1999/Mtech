def remove_char(string):
    s = set()
    list = []
    for i in string:
        if i not in s:
            s.add(i)
            list.append(i)
    return ''.join(list)


string = input("Enter String:")
result = remove_char(string)
print("String after removing duplication is: "+result)
