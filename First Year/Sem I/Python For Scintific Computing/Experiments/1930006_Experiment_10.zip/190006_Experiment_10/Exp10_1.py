import pandas as pd
data = pd.read_csv("iris.csv")
print(data.describe())