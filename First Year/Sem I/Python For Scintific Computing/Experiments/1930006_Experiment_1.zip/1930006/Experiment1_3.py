# 3.	Add two numbers
class Experiment1_3:

    def addTwoNumbers(firstNumber, secondNumber):
        return firstNumber + secondNumber

    try:
        firstNumber = input("Enter the firstNumber : ")
        secondNumber = input("Enter the secondNumber : ")
        sum = addTwoNumbers(firstNumber, secondNumber)
        print('Addition of two numbers is ' + str(sum))

    except:
        print("please enter numbers in integer")
