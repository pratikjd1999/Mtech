class Shape:
    # width, height
    def __init__(self, a, b):
        self.width = a
        self.height = b
    def get_data(self, a = 0, b = 0):
        self.width = a
        self.height = b

    def disply_area(self):
        print("Parent class area =>")

class Rectangle(Shape):
    def __init__(self, a, b):
        Shape.get_data(self, a, b)

    def disply_area(self):
        area = self.width * self.height
        print("Rectangle class area =>", area)


class Triangle(Shape):
    def __init__(self, a, b):
        Shape.get_data(self, a, b)

    def get_data( a=0, b=0):
        pass

    def disply_area(self):
        area = self.width * self.height / 2
        print("Triangle class area =>", area)

class MainClass:
    def calculate():
        ch = int(input(" 1.Triangle\n 2.Rectangle\n 3.To Exit\n"))
        if ch == 1:
            a = int(input("Enter Your width:"))
            b = int(input("Enter Your height:"))
            obj = Triangle(a, b)
            obj.disply_area()
        elif ch == 2:
            a = int(input("Enter Your width:"))
            b = int(input("Enter Your height:"))
            obj = Rectangle(a, b)
            obj.disply_area()
        elif ch == 3:
            print("Thank You")
            exit(0)
        else:
            print("Choice code does not match to any option")

    calculate()