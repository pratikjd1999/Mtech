def largest_element(arr,size):
    max=arr[0]
    for i in range(1,size):
        if arr[i]>max:
            max=arr[i]
    return max


try:
    number = int(input("Enter array Range:"))
    arr = []
    for i in range(1, number+1):
        ele = int(input("Enter array element"))
        arr.append(ele)
        i+1
    print(arr)  
    size=len(arr)  
    large_ele=largest_element(arr,size)
    print("Largest Element in Array:"+str(large_ele))
except:
    print("Error in input please enter integer values only")
