givenList = [1, 3, 5, 7, 9]
print("Given list is \n", givenList)
result = [(i, pow(i, 3)) for i in givenList]
print("\nresultant list is \n", result)