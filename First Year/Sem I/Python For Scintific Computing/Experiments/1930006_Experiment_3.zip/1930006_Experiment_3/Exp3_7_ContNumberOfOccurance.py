def countX(lst, x): 
    return lst.count(x) 
  
# Driver Code 
lst = [8, 6, 8, 10, 8, 20, 10, 8, 8] 
print("Given List is ", lst)
x = 8
print('finding occurance of element =', x)
print('{} has occurred {} times'.format(x, countX(lst, x))) 
