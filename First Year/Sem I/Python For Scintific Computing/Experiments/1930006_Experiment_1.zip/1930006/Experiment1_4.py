# 4.	Python Program to calculate the square root
class Experiment1_4:

    def calculateSquareRoot(number):
        return number * number
        
    try:
        numberToSquare = input("Enter the number : ")
        squareRoot = calculateSquareRoot(numberToSquare)
        print("Square Root of given numbers is " + str(squareRoot))

    except:
        print("please enter number in integer")
