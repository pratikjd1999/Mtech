def decimalToBinary(n):  
  
    if(n > 1):  
        decimalToBinary(n//2)  
    print(n%2, end=' ') 
      
      
  
# Driver code  
if __name__ == '__main__':  
    input_num = int((input("Enter any Number: ")))
    decimalToBinary(input_num)  
    print("\n") 
   