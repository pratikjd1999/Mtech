print("\nSorting Numbers:")
list = [10, 5, 3, 1, 2, 6]
print("List Before sorting: "+str(list))
list.sort()
print("List after sorting: "+str(list))

print("\nSorting Alphabets:")
listAlphabets=["i", "b", "e", "t", "o", "s"]
print("List Before sorting: "+str(listAlphabets))
listAlphabets=sorted(listAlphabets)
print("List after sorting: "+str(listAlphabets))