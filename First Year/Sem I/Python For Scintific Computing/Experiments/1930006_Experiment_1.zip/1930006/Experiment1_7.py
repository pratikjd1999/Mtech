# 7.	Python program to swap two variables
class Experiment1_7:
    def swapTwoVariables(variable_1, variable_2):
       temp=variable_1
       variable_1=variable_2
       variable_2=temp
       print('variables after swapping are variable_1 = {0} and variable_2 = {1}'.format(variable_1,variable_2))


    try:
        variable_1 = input("Enter the variable_1 : ")
        variable_2 = input("Enter the variable_2 : ")
        print('variables before swapping are variable_1 = {0} and variable_2 = {1}'.format(variable_1,variable_2))
        swapTwoVariables(variable_1, variable_2)
    
    except:
        print("please enter height and base in integer")

