inputFileName = (input("Enter input file name : "))
destinationFileName = (input("Enter destination file name : "))

fn = open(inputFileName+'.txt', 'r') 
  
# open other file in write mode 
fn1 = open(destinationFileName+'.txt', 'w') 
  
# read the content of the file line by line 
cont = fn.readlines() 
type(cont) 
for i in range(0, len(cont)): 
        fn1.write(cont[i]) 
   
fn1.close() 
  
fn1 = open('nfile.txt', 'r') 
  
# read the content of the file 
cont1 = fn1.read() 
  
print("content of the destination file ")
print(cont1) 
  
fn.close() 
fn1.close() 