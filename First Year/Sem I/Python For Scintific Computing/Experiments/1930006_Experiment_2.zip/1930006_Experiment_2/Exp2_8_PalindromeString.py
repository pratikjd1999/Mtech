inputString = str(input("Enter a string:"))
temporaryString = inputString[::-1]

if temporaryString == inputString:
    print("Entered string is palindrome")
else:
    print("Entered string is not palindrome")
