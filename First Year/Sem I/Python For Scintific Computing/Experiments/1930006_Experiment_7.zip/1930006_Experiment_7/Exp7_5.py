import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="root",
  database="CollegeInfo"
)

mycursor = mydb.cursor()
mycursor.execute("SELECT * FROM students WHERE TIMESTAMPDIFF(YEAR, DateofBirth, CURDATE()) >= 15")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)