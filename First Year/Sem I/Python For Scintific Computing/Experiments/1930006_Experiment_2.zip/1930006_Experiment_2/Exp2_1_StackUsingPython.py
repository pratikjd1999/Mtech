stack_array=[]
top_position=-1
def push(top_position):
    element=int(input("Enter element to insert in stack:"))
    top_position+=1
    stack_array.append(element)
    #print(stack_array)
    return
def pop(top_position):
    if(top_position<0):
        print("stack is empty nothing to pop")
    else:
        poppedElement=stack_array.pop(top_position)
        print("Popped element is ",poppedElement)
    return
while(1):
    print(" 1.To push element\n 2.To Pop element\n 3.To Display Stack\n 4.To Exit\n")
    try:
        ch=int(input("Enter Your Choice:"))
        if ch==1:
            push(top_position)
            top_position+=1
            continue
        elif ch==2:
            pop(top_position)
            top_position-=1
            continue
        elif ch == 3:
            print(stack_array)
            continue
        elif ch==4:
            print("Thank You")
            break
        else:
            print("Choice code does not match to any option")
    except:
        print("Error in input please enter integer values only")

