from Arithmatics import *

a = 10
b = 2

print(add(a, b))

print(sub(a, b))

print(mul(a, b))

print(div(a, b))