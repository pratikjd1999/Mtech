def getPrimeNumbersInRange(input_range):
    for number in range(2, input_range + 1):
        for i in range(2, number):
            if (number % i) == 0:
                break
        else:
            print(number)

try:
    input_range = int(input("Enter any number:"))
    getPrimeNumbersInRange(input_range)
except:
    print ("Entered number not integer, Please enter integer values only ")
