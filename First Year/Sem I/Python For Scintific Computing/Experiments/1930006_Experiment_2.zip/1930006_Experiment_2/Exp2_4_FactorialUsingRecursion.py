
def getfactorial(number):
    if number == 1:
       return number
    else:
       return number * getfactorial(number - 1)
try:
    number = int(input("Enter any number:"))
    result = getfactorial(number);

    print("Factorial of entered number:  "+str(result))
except:
        print("Error in input please enter integer values only")