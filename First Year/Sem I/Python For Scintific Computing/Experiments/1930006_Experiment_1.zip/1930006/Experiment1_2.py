# 2.	Print Hello world
class Experiment1_2:
      print("Hello world")

