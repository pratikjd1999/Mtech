
list = ["orange", "green", "blue", "red", "black"]
print("List before reverse:\n"+str(list))
reverseList=list[::-1]
print("\nList After Reverse:\n"+str(reverseList))