class Distance:

    def __init__(self, km, m, cm):
        self.km = km
        self.m = m
        self.cm = cm


    def __add__(self, other):
        km = self.km + other.km
        m = self.m + other.m
        cm = self.cm + other.cm

        d3 = Distance(km, m, cm)

        return d3



dist1 = Distance(2, 90, 10)
dist2 = Distance(3, 9, 5)

print("dist1 =>", dist1.__dict__)
print("dist2 =>", dist2.__dict__)

dist3 = dist1 + dist2
print("resultant dist3 =>")

print(dist3.__dict__)