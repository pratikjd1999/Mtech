import os.path
# b.While copying source file to destination file assert that Source file should exist in “current” directory.\

fileName = "abc.txt"
assert(os.path.exists(fileName)), "File Does Not Exist"
f = open(fileName)
f1 = open('output.txt', 'a')
for x in f.readlines():
    f1.write(x)
f.close()
f1.close()
