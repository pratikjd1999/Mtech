# c.File opening error
try:
    fileName = "abc.txt"
    file = open(fileName, 'r')

except IOError:
    print("Error in opening file %s" % fileName)

