fn = open('exp10SampleText.txt', 'r') 
  
fn1 = open('newfile.txt', 'w') 

input_num = int((input("Enter Line number to delete (1-10): ")))

cont = fn.readlines() 
type(cont) 
print(input_num)

for i in range(0, len(cont)):
    if(i != input_num - 1): 
        fn1.write(cont[i]) 
    else: 
        pass
  
fn1.close() 
  
fn1 = open('newfile.txt', 'r') 
  
cont1 = fn1.read() 
  
print(cont1) 
  
fn.close() 
fn1.close() 