# 5.	Python Program to find the area of triangle
class Experiment1_5:

    def calculateAreaOfTriangle(height, base):
        return 0.5 * height * base
    try:
        height = input("Enter the height : ")
        base = input("Enter the base : ")
        areaOfTriangle = calculateAreaOfTriangle(height, base)
        print("Area of given triangle is " + str(areaOfTriangle))

    except:
        print("please enter height and base in integer")
