# a.Demonstrate Divide By Zero error
try:
    x = 5
    y = 0
    z = (x / y)
except ZeroDivisionError:
    print("Error Dividing %d/%d" % (x, y))

