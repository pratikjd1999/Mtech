import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="root",
  database="CollegeInfo"
)
# ******Order By*****
mycursor = mydb.cursor()
mycursor.execute("SELECT * FROM students  ORDER BY name")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)




# ******Update table****

mycursor1 = mydb.cursor()
mycursor1.execute("UPDATE students SET name = 'Hannah123' WHERE Roll_number = 3")

mydb.commit()

print(mycursor1.rowcount, "record(s) affected")





# ****** Delete column****

mycursoer2 = mydb.cursor()
mycursoer2.execute("ALTER TABLE students DROP COLUMN DateofBirth")

mydb.commit()




# ******Drop table****

mycursor3 = mydb.cursor()

sql = "DROP TABLE students"
mycursor3.execute(sql)




# ******Limit****

mycursor4 = mydb.cursor()

mycursor4.execute("SELECT * FROM students LIMIT 5")

myresult = mycursor4.fetchall()

for x in myresult:
  print(x)