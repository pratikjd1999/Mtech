import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="root",
  database="CollegeInfo"
)

mycursor = mydb.cursor()

sql = "INSERT INTO students (Roll_number, name, DateofBirth, PercentageMarks) VALUES (%s, %s, %s, %s)"
val = [
  (1, 'Peter', '12Aug1992', '70'),
  (2, 'Amy', '29Aug1992', '65'),
  (3, 'Hannah', '22Sept1994', '59'),
  (4, 'Michael', '14Sept1994', '95'),
  (5, 'Sandy', '19Sept1995', '45'),
  (6, 'Betty', '10Oct1996', '70'),
  (7, 'Richard', '2Oct1997', '56'),
  (8, 'Susan', '16Nov1999', '84'),
  (9, 'Vicky', '16Nov1990', '77'),
  (10, 'Ben', '12Dec1999', '60'),
]

mycursor.executemany(sql, val)

mydb.commit()

print(mycursor.rowcount, "was inserted.")