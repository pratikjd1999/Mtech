import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="root",
  database="CollegeInfo"
)

mycursor = mydb.cursor()

mycursor.execute("CREATE TABLE students (Roll_number INT PRIMARY KEY, name VARCHAR(255), DateofBirth VARCHAR(255), PercentageMarks  VARCHAR(255))")