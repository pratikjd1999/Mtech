def mainFunction():

    print("Function Called From This File")

if __name__ == "__main__":
    mainFunction()
else:
    print("File is not main file (imported file)")