A = [[12,7,3],
    [4 ,5,6],
    [7 ,8,9]]

print("first matrix is ", A)

B = [[5,8,1],
    [6,7,3],
    [4,5,9]]

print("second matrix is ", B)

result = [[0,0,0],
         [0,0,0],
         [0,0,0]]

# iterate through rows
print("Resultant matrix is ")

for i in range(len(A)):
   # iterate through columns
   for j in range(len(A[0])):
       result[i][j] = A[i][j] + B[i][j]
for row in result:
   print(row)
