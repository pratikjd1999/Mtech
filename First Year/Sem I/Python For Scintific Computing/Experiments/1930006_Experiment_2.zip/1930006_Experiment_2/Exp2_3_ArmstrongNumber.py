def arms_num(inputNumber):
    sum=0
    order = len(str(inputNumber))
    while inputNumber > 0:
        digit = inputNumber % 10
        sum += digit**order
        inputNumber //= 10
    return(sum)


try:
    inputNumber = int(input("Enter Any number to check:"))
    sum = arms_num(inputNumber)
    if sum == inputNumber:
        print("Number is Armstrong number")
    else:
        print("Number is not Armstrong number")
except:
    print ("Entered number not integer, Please enter integer values only ")